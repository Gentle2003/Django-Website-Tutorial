from django.contrib import admin
from .models import Pricing, Offer


class OfferAdmin(admin.ModelAdmin):
    list_display = ('code', 'discount')

class PricingAdmin(admin.ModelAdmin):
    list_display = ('name', 'price', 'stock')

admin.site.register(Offer, OfferAdmin)
admin.site.register(Pricing, PricingAdmin)
