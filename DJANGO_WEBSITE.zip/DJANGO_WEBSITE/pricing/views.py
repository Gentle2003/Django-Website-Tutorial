from django.http import HttpResponse
from django.shortcuts import render
from .models import Pricing

# Create your views here.
def index(request):
    pricing_view = Pricing.objects.all()
    return render(request, 'index.html', {'pricings': pricing_view})

def news_items(request):
    return HttpResponse("This is the news page fam.Take note")